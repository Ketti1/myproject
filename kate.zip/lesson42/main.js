let a = document.getElementById("test3")
//   b = a.innerHTML
//   a.innerHTML ="Здесь был параграф 3"
// alert(b)
// a.innerHTML ="Здесь был параграф 3"
// console.log(a.innerHTML);

// let aDom = document.getElementsByClassName("dom")
// console.log(aDom);
a.setAttribute("class","dom")