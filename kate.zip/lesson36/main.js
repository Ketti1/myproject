1. // let a = Number(prompt("Введите число"))
// if (a > 0) {
//     a++
// }
// alert(a)

2. // let a = prompt("Введите число")
// if (a > 0) {
//     a++
// }
// else if (a < 0){
//     a = a-2
// }
// alert(a)

3. // let a = Number(prompt("Введите число"))
// if (a > 0) {
//      a++
// }
// else if (a < 0){
//    a = a-2
// }
// else if (a == 0){
//     a = a + 10
// }
// alert(a)

// let a = Number(prompt("Вв"))
//     b = Number(prompt("Bb"))
//     z = a + b
// console.log(z)

4. // let a = Number(prompt("Введите число"))
//     b = Number(prompt("Введите число"))
//     c = Number(prompt("Введите число"))
// if (a>0 && b>0 && c>0) {
//     alert(3)
// }
// else if (a>0 && b>0 && c<0) {
//     alert(2)
// }
// else if(a>0 && b<0 && c<0) {
//     alert(1)
// }
// else {
//     alert(0)
// }

6. // let a = Number(prompt("Введите число"))
//     b = Number(prompt("Введите число"))
// if (a > b) {
//     alert(a)
// } 
// else if (a < b) {
//     alert(b)
// }

5. // let a = Number(prompt("Введите число"))
//     b = Number(prompt("Введите число"))
//     c = Number(prompt("Введите число"))
// if (a>0 && b>0 && c>0) {
//     alert(3)
// }
// else if (a>0 && b>0 && c<0) {
//     alert(2)
// }
// else if(a>0 && b<0 && c<0) {
//     alert(1)
// }
// else if (a == 0 && b == 0 && c == 0){
//     alert(0)
// }
// if (a<0 && b<0 && c<0) {
//     alert(3)
// }
// else if (a<0 && b<0 && c>0) {
//     alert(2)
// }
// else if(a<0 && b>0 && c>0) {
//     alert(1)
// }