// let x = "Vica"
// console.log(x)
// alert(x) 
// let userName = prompt("КАК ТЕБЯ ЗОВУТ ?")
// alert(userName)
// console.log(userName)

// let x = "" + 1 + 0
// console.log(x)
// let y = true + false
// console.log(y)
// let a = 6 / "3"
// console.log(a)
// let b = 4 + 5 + "px"
// console.log(b)
// let c = "px" + 5 + 4
// console.log(c)
// let d = "4" - 2
// console.log(d)
// let e = Number(prompt(Введите первое число?))
// f = Number(prompt(Введите второе число?))
// alert(e + f)
// console.log(5 > 4)
// console.log("ананас">"яблоко")
// console.log("2" > "12")
// console.log("Roma"< "Romanuch")
// let k = prompt("a"="")
// l = prompt("b"="")
// k++
// k +=l
// alert(a > b)
// let a = prompt("Какое число?")
// if (a== 10) {
//     alert("Юля молодец")
// }
// else {
//     alert("Юля не молодец")
// }
let a = prompt("Сколько тебе лет?")
if ( a < 7) {
    alert("Ты малыш")
}
else if( a < 18) {
    alert("Ты школьник")
}
else if() {
    alert("Ты взрослый человек")
}

