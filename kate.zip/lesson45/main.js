let number = document.getElementById('number');
let userName = document.getElementById('name');
let cardDate = document.getElementById('date');
let cardYear = document.getElementById('year');
let cardType = document.getElementById('type');
let card_Number = document.getElementById('card_number');
let card_Name = document.getElementById('card_name');
let card_Month = document.getElementById('card_month');
let card_Year = document.getElementById('card_year');
number.addEventListener('keyup', setNumber)
userName.addEventListener('keyup', setName)
cardDate.addEventListener('mouseup', setData)
cardYear.addEventListener('mouseup', setYear)
function isNum(num){
    return !/[^.[0-9, " "]]*/.text(num)
}
function isType(type){
    if(type.includes(5868)){
        cardType.innerHTML = "Visa"
    }
    else if(type.includes(4941)){
        cardType.innerHTML = "MasterCard"
    }
    else{
        cardType.innerHTML = "Undefound"
    }
}
function setNumber(e) {
    e.preventDefault
    if (isNum(number.value)) {
        card_number.innerHTML = number.value
    }
    else
    {
        alert ('only numbers')
    }
    check_bank(number.value)
}
function setName(){
}
function setData(){
}
function setYear(){
}