1. // let a = +prompt("Введите число")
// switch (a) {
//     case 0:
//         alert("Верно"); 
//     break;
//     default:
//         alert("Неверно");
// }

2. // let a = +prompt("Введите число")
// switch (a>0) {
//     case true: 
//     alert("Верно");
//     default:
//         alert("Неверно");
// }

3. // let a = +prompt("Введите число")
// switch (a<0) {
//     case true:
//         alert("Верно");
//      default:
//         alert("Неверно");
// }

4. // let a = +prompt("Введите число")
// switch (a>=0) {
//     case true:
//         alert("Верно");
//     default:
//         alert("Неверно");
// }

5. // let a = +prompt("Введите число")
// switch (a<=0) {
//     case true:
//         alert("Верно");
//     default:
//         alert("Неверно");
// }

6. // let a = +prompt("Введите число")
// switch (a != 0) {
//     case true:
//         alert("Верно");
//     default:
//         alert("Неверно");
// }

7. // let a = prompt("Введите число")
// switch (a == "test") {
//     case true:
//         alert("Верно");
//     default:
//         alert("Неверно");
// }

8. // let a = prompt("Введите число")
// switch (a) {
//     case "1":
//         alert("Верно");
//         break;
//     case '"1"':
//         alert("Верно");
//         break;
//     default:
//         alert("Неверно");
// }